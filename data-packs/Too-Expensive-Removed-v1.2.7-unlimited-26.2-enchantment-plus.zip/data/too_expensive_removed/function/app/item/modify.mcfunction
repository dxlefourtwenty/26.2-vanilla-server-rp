advancement revoke @s only too_expensive_removed:inventory_changed

item modify entity @s player.cursor too_expensive_removed:repair_cost
