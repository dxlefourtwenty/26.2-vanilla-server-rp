item modify entity @s armor.head too_expensive_removed:repair_cost
item modify entity @s armor.chest too_expensive_removed:repair_cost
item modify entity @s armor.legs too_expensive_removed:repair_cost
item modify entity @s armor.feet too_expensive_removed:repair_cost
item modify entity @s weapon.offhand too_expensive_removed:repair_cost
