scoreboard objectives add feather dummy
scoreboard objectives add wool dummy



