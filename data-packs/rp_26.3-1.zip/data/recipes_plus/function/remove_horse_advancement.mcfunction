advancement revoke @a only recipes_plus:recipes/others/horse_armors
advancement revoke @a only recipes_plus:recipes/others/glowstone_dust_recipes