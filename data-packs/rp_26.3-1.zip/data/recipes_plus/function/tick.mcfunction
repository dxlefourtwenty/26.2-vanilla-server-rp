#chicken
execute as @e[type=chicken,scores={feather=0}] at @s run function recipes_plus:_shed

scoreboard players remove @e[type=chicken,scores={feather=0..}] feather 1

execute as @e[type=chicken] unless entity @s[scores={feather=0..}] store result score @s feather run random value 4000..9000

#sheep
#execute as @e[type=sheep,scores={wool=0}] at @s run function recipes_plus:_shed

#scoreboard players remove @e[type=sheep,scores={wool=0..}] wool 1

#execute as @e[type=sheep] unless entity @s[scores={wool=0..}] store result score @s wool run random value 4000..9000

#Let's find out how to show arms for all armor stands
execute as @e[type=armor_stand] run data merge entity @s {ShowArms:1b}
#It was much easier than expected
