loot spawn ~ ~ ~ loot recipes_plus:feather
playsound minecraft:entity.chicken.egg

