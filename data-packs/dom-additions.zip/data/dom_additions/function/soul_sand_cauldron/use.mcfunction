advancement revoke @s only dom_additions:soul_sand_cauldron/use
execute store result score @s dom.ss_ray run attribute @s minecraft:block_interaction_range get 8
execute anchored eyes positioned ^ ^ ^0.125 run function dom_additions:soul_sand_cauldron/find_cauldron
