execute if block ~ ~ ~ minecraft:lava_cauldron run return run function dom_additions:soul_sand_cauldron/find_sand
scoreboard players remove @s dom.ss_ray 1
execute if score @s dom.ss_ray matches 1.. positioned ^ ^ ^0.125 run function dom_additions:soul_sand_cauldron/find_cauldron
