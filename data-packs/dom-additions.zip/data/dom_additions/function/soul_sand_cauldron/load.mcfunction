scoreboard objectives add dom.ss_ray dummy
