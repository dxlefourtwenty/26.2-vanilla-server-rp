setblock ~ ~ ~ minecraft:air replace
scoreboard players set @s dom.ss_ray 16
execute positioned ^ ^ ^0.125 run function dom_additions:soul_sand_cauldron/finish
