setblock ~ ~ ~ minecraft:cauldron replace
give @s minecraft:soul_sand 1
playsound minecraft:block.lava.extinguish block @a[distance=..16] ~ ~ ~ 1 1
particle minecraft:large_smoke ~ ~0.75 ~ 0.2 0.25 0.2 0.01 12 force
