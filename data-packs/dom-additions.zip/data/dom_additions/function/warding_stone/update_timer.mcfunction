execute if stopwatch dom_additions:warding_stone_damage 0.51.. run stopwatch restart dom_additions:warding_stone_damage
