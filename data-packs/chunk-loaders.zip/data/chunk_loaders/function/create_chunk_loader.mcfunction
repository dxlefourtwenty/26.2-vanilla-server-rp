summon minecraft:marker ~0.5 ~ ~0.5 {Tags:["chuLoa.marker"]}
particle minecraft:smoke ~0.5 ~0.5 ~0.5 0.4 0.4 0.4 0.02 150
playsound minecraft:block.respawn_anchor.charge block @a ~ ~ ~ 1 0.5
kill @s
