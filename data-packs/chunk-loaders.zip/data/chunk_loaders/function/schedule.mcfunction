schedule function chunk_loaders:schedule 1s
execute as @e[type=minecraft:item] at @s positioned ~ ~-0.25 ~ if block ~ ~ ~ minecraft:lodestone align xyz unless entity @e[tag=chuLoa.marker,distance=..1] if entity @s[nbt={Item:{id:"minecraft:diamond",count:1}}] run function chunk_loaders:try_to_create_chunk_loader
execute at @e[tag=chuLoa.marker] align xyz run particle minecraft:smoke ~0.5 ~0.5 ~0.5 0.25 0.25 0.25 0.02 4
