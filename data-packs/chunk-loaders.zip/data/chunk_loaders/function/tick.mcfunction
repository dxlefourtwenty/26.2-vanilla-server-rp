schedule function chunk_loaders:tick 1t
execute as @e[tag=chuLoa.marker] at @s unless block ~ ~ ~ minecraft:lodestone run function chunk_loaders:destroy_chunk_loader
