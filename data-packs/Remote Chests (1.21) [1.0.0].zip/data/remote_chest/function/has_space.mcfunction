execute store result score @s remote_chest_space run loot insert ~ ~ ~ loot remote_chest:has_space
data remove block ~ ~ ~ Items[{id:"minecraft:structure_void"}]
execute if score @s remote_chest_space matches 1.. run return 1
scoreboard players reset @s remote_chest_space
return fail