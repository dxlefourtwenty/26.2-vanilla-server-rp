execute as @e[type=minecraft:item_frame,nbt={Item:{id:"minecraft:ender_pearl"}}] if data entity @s Item.components."minecraft:custom_name" at @s if block ~ ~-1 ~ minecraft:chest if data block ~ ~-1 ~ Items[-1] run function remote_chest:process_chest with entity @s

schedule function remote_chest:tick 8t replace