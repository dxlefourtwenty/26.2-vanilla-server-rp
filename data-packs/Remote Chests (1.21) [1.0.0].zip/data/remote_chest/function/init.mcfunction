scoreboard objectives remove remote_chest_space
scoreboard objectives add remote_chest_space dummy

scoreboard objectives remove remote_chest_success
scoreboard objectives add remote_chest_success dummy

schedule function remote_chest:tick 8t replace