# Initialise le scan periodique optimise
schedule function faster_spawns:dispatch 5s replace
