# Fonction vide : la logique utilise /schedule pour etre plus legere
