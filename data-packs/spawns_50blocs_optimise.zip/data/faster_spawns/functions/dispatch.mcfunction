# Scanne un seul joueur a la fois pour limiter le lag
execute as @a[gamemode=!spectator,limit=1,sort=random] at @s run function faster_spawns:scan
schedule function faster_spawns:dispatch 5s replace
