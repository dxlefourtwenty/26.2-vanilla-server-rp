Nom du pack
Boosted Spawners - 50 Block Activation

Description FR
Boostez vos spawners vanilla et transformez vos donjons, farms et zones de survie en véritables défis dynamiques.

Boosted Spawners augmente la portée d'activation des spawners jusqu'à 50 blocs et améliore leur comportement pour offrir une expérience plus intense, plus pratique et plus rentable. Les spawners deviennent plus efficaces sans mod, tout en restant simples à installer dans n'importe quel monde compatible.

Fonctionnalités
- Portée d'activation augmentée jusqu'à 50 blocs
- Plus de mobs générés par vague
- Spawners plus utiles pour les farms et les bases
- Gameplay survie plus nerveux et plus vivant
- Installation simple en datapack, sans mod

Notes
- Le pack utilise une version optimisée pour limiter le lag
- Les spawners sont modifiés lorsqu'ils sont détectés près d'un joueur
- Idéal pour les mondes survie, les serveurs entre amis et les bases à spawner
