scoreboard players set $entity_width jbt.iris 1700000
scoreboard players set $entity_height jbt.iris 2375000
