scoreboard players set $entity_width jbt.iris 1375000
scoreboard players set $entity_height jbt.iris 562500
