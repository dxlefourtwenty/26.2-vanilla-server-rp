particle minecraft:large_smoke ~ ~0.25 ~ 0.25 0.5 0.25 0.01 20
kill @e[distance=..3,type=minecraft:item,nbt={Item:{id:"minecraft:lodestone"}}]
summon minecraft:item ~ ~ ~ {Item:{id:"minecraft:blaze_powder",count:7}}
kill @s
