execute unless entity @s[tag=dom_additions.warding_stone_setup] run function dom_additions:warding_stone/setup
function dom_additions:warding_stone/effects
execute if entity @s[tag=dom_additions.warding_stone_setup] unless block ~ ~ ~ minecraft:lodestone run function dom_additions:warding_stone/remove
