execute unless entity @e[type=#dom_additions:villager_friends,distance=..16,nbt={active_effects:[{id:"minecraft:regeneration"}]}] run effect give @e[type=#dom_additions:villager_friends,distance=..16] minecraft:regeneration 3 0 true
particle minecraft:soul_fire_flame ~ ~0.5 ~ 0.5 0.5 0.5 0 1
effect give @e[type=#minecraft:undead,distance=..26] minecraft:slowness 2 1 true
execute unless stopwatch 0.5s ..0.4 at @n[type=#minecraft:undead,distance=..24] unless entity @n[type=minecraft:wither,distance=..20] run particle minecraft:soul_fire_flame ~ ~2 ~ 0.25 0.25 0.25 0.025 1
execute unless stopwatch 0.5s ..0.4 at @n[type=minecraft:wither,distance=..24] run particle minecraft:soul_fire_flame ~ ~2.5 ~ 1 1 1 0.5 2
execute unless stopwatch 0.5s ..0.4 at @n[type=#minecraft:undead,distance=..24] unless entity @n[type=minecraft:wither,distance=..20] run damage @n[type=#minecraft:undead,distance=..14] 7 minecraft:out_of_world
execute unless stopwatch 0.5s ..0.4 at @n[type=minecraft:wither,distance=..24] run damage @n[type=#minecraft:undead,distance=..14] 2 minecraft:out_of_world
