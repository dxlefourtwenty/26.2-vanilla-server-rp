execute as @e[type=minecraft:armor_stand,tag=dom_additions.warding_stone] at @s run function dom_additions:warding_stone/tick_instance
