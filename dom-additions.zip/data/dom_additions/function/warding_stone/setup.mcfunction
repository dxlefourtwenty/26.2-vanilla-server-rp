setblock ~ ~ ~ minecraft:lodestone
playsound minecraft:entity.wither.spawn block @a ~ ~ ~ 0.25
particle minecraft:sculk_soul ~ ~0.5 ~ 0.25 0.1 0.25 0.05 10
particle minecraft:soul_fire_flame ~ ~0.5 ~ 0.5 0.1 0.5 0.1 10
tag @s add dom_additions.warding_stone_setup
