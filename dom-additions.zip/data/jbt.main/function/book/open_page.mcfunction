$dialog show @s $(dialog)
