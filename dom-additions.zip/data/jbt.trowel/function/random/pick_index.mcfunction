$return run random value 0..$(block_count)
