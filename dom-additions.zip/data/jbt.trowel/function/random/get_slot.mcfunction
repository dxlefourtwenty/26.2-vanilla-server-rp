$return run data get storage jbt:trowel blocks[$(chosen_index)]
