return run function jbt.chisel:check/same_macro with storage jbt:temp chisel
