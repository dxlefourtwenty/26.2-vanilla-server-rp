$setblock ~ ~ ~ $(chosen_block)[persistent=true] replace
