$execute if entity @s[gamemode=!creative] run clear @s $(chosen_block) 1
