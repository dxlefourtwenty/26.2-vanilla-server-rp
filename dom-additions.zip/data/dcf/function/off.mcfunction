function dcf:toggle {enabled: false}
