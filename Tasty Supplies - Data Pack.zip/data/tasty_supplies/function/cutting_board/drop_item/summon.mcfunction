$summon minecraft:item ~ ~.5 ~ {Item:$(item)}
