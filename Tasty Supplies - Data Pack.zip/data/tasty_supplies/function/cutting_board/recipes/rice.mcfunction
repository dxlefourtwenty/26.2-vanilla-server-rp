summon minecraft:item ~ ~.5 ~ {Item:{'components': {'custom_data': {'ts_name': 'rice', 'ts_hash': '4bcb28af4d5535b886428aa3828489b53f7b4811'}, 'custom_model_data': {'strings': ['tasty_supplies/rice']}, 'item_name': 'Rice', 'max_stack_size': 64, 'rarity': 'common'}, 'count': 4, 'id': 'minecraft:arms_up_pottery_sherd'}}
kill @s
