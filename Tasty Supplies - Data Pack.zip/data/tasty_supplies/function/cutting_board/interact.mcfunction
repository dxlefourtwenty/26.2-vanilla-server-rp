execute at @s on target if data entity @s SelectedItem.components."minecraft:custom_data".ts_cutting_tool run return run execute as @e[type=interaction, sort=nearest, limit=1] run data remove entity @s interaction
execute at @s if entity @e[type=item_display, tag=cutting_board_slice, distance=..1] run execute as @e[type=interaction, sort=nearest, limit=1] run data remove entity @s interaction
execute at @s if entity @e[type=item_display, tag=cutting_board_slice, distance=..1] run return fail
data modify storage minecraft:temp cutting_board set value {custom_item: false}
execute on target if data entity @s SelectedItem.components run data modify storage minecraft:temp cutting_board set value {custom_item: true}
execute at @s on target run function tasty_supplies:cutting_board/place_item/main with entity @s SelectedItem
data remove entity @s interaction
