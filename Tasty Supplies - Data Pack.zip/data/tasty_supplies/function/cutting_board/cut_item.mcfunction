execute if data entity @s item.components."minecraft:custom_data"{tags:["cutting_board_display"]} run return 0
execute if data entity @s item{id: "minecraft:bread", components: {"minecraft:custom_model_data": {"strings": ["tasty_supplies/apple_pie"]}}} run function tasty_supplies:cutting_board/recipes/apple_pie_slice
execute if data entity @s item{id: "minecraft:bread", components: {"minecraft:custom_model_data": {"strings": ["tasty_supplies/chocolate_pie"]}}} run function tasty_supplies:cutting_board/recipes/chocolate_pie_slice
execute if data entity @s item{id: "minecraft:bread", components: {"minecraft:custom_model_data": {"strings": ["tasty_supplies/cherry_blossom_pie"]}}} run function tasty_supplies:cutting_board/recipes/cherry_blossom_pie_slice
execute if data entity @s item{id: "minecraft:bread", components: {"minecraft:custom_model_data": {"strings": ["tasty_supplies/chorus_pie"]}}} run function tasty_supplies:cutting_board/recipes/chorus_pie_slice
execute if data entity @s item{id: "minecraft:bread", components: {"minecraft:custom_model_data": {"strings": ["tasty_supplies/glow_berry_pie"]}}} run function tasty_supplies:cutting_board/recipes/glow_berry_pie_slice
execute if data entity @s item{id: "minecraft:bread", components: {"minecraft:custom_model_data": {"strings": ["tasty_supplies/sweet_berry_cheesecake"]}}} run function tasty_supplies:cutting_board/recipes/sweet_berry_cheesecake_slice
execute if data entity @s item{id: "minecraft:bread", components: {"minecraft:custom_model_data": {"strings": ["tasty_supplies/cheese"]}}} run function tasty_supplies:cutting_board/recipes/cheese_slice
execute if data entity @s item{id: "minecraft:baked_potato"} run function tasty_supplies:cutting_board/recipes/potato_fries
execute if data entity @s item{id: "minecraft:bread", components: {"minecraft:custom_model_data": {"strings": ["tasty_supplies/kelp_roll"]}}} run function tasty_supplies:cutting_board/recipes/kelp_roll_slice
execute if data entity @s item{id: "minecraft:snort_pottery_sherd", components: {"minecraft:custom_model_data": {"strings": ["tasty_supplies/wheat_dough"]}}} run function tasty_supplies:cutting_board/recipes/raw_pasta
execute if data entity @s item{id: "minecraft:porkchop"} run function tasty_supplies:cutting_board/recipes/raw_bacon
execute if data entity @s item{id: "minecraft:cod"} run function tasty_supplies:cutting_board/recipes/raw_cod_slice
execute if data entity @s item{id: "minecraft:salmon"} run function tasty_supplies:cutting_board/recipes/raw_salmon_slice
execute if data entity @s item{id: "minecraft:wheat"} run function tasty_supplies:cutting_board/recipes/rice
