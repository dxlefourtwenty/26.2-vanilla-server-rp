scoreboard objectives add ts_join minecraft.custom:minecraft.leave_game
