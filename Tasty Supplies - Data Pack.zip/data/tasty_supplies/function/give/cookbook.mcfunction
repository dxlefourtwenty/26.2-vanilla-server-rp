give @s minecraft:written_book[custom_data={ts_name:"cookbook",ts_hash:"fb099c57cffed803a6e377198b60a64b3e45fd47"},custom_model_data={strings:["tasty_supplies/cookbook"]},enchantment_glint_override=false,item_name="Cookbook",max_stack_size=1,rarity="epic",written_book_content={author:"A Forgotten Chef",generation:3,pages:[{raw:{extra:[{bold:true,color:"red",font:"minecraft:stwr",italic:true,text:"[WIP]
"},{color:"gold",font:"minecraft:stwb",text:"Tasty Supplies
"},{color:"gold",font:"minecraft:stwb",text:"   Cookbook
"},{text:"


"},{color:"dark_gray",font:"minecraft:stwr",text:"   Recipes &
"},{color:"dark_gray",font:"minecraft:stwr",text:"    Guides
"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"    Sweets"},{text:"



"},{click_event:{action:"change_page",page:10},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 10"},text:""},{click_event:{action:"change_page",page:11},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 11"},text:""},{click_event:{action:"change_page",page:12},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 12"},text:""},{click_event:{action:"change_page",page:13},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 13"},text:""},{click_event:{action:"change_page",page:14},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 14"},text:""},{click_event:{action:"change_page",page:15},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 15"},text:""},{click_event:{action:"change_page",page:16},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 16"},text:""},{text:"

"},{click_event:{action:"change_page",page:17},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 17"},text:""},{click_event:{action:"change_page",page:18},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 18"},text:""},{click_event:{action:"change_page",page:19},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 19"},text:""},{click_event:{action:"change_page",page:20},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 20"},text:""},{click_event:{action:"change_page",page:21},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 21"},text:""},{click_event:{action:"change_page",page:22},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 22"},text:""},{click_event:{action:"change_page",page:23},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 23"},text:""},{text:"

"},{click_event:{action:"change_page",page:24},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 24"},text:""},{click_event:{action:"change_page",page:25},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 25"},text:""},{click_event:{action:"change_page",page:26},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 26"},text:""},{click_event:{action:"change_page",page:27},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 27"},text:""},{click_event:{action:"change_page",page:28},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 28"},text:""}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"    Drinks"},{text:"



"},{click_event:{action:"change_page",page:29},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 29"},text:""},{click_event:{action:"change_page",page:30},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 30"},text:""},{click_event:{action:"change_page",page:31},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 31"},text:""},{click_event:{action:"change_page",page:32},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 32"},text:""},{click_event:{action:"change_page",page:33},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 33"},text:""},{click_event:{action:"change_page",page:34},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 34"},text:""},{click_event:{action:"change_page",page:35},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 35"},text:""},{text:"

"},{click_event:{action:"change_page",page:36},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 36"},text:""},{click_event:{action:"change_page",page:37},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 37"},text:""}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"     Meals"},{text:"



"},{click_event:{action:"change_page",page:38},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 38"},text:""},{click_event:{action:"change_page",page:39},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 39"},text:""},{click_event:{action:"change_page",page:40},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 40"},text:""},{click_event:{action:"change_page",page:41},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 41"},text:""},{click_event:{action:"change_page",page:42},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 42"},text:""},{click_event:{action:"change_page",page:43},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 43"},text:""},{click_event:{action:"change_page",page:44},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 44"},text:""},{text:"

"},{click_event:{action:"change_page",page:45},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 45"},text:""},{click_event:{action:"change_page",page:46},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 46"},text:""},{click_event:{action:"change_page",page:48},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 48"},text:""},{click_event:{action:"change_page",page:50},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 50"},text:""},{click_event:{action:"change_page",page:51},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 51"},text:""},{click_event:{action:"change_page",page:52},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 52"},text:""},{click_event:{action:"change_page",page:53},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 53"},text:""},{text:"

"},{click_event:{action:"change_page",page:54},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 54"},text:""},{click_event:{action:"change_page",page:55},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 55"},text:""},{click_event:{action:"change_page",page:56},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 56"},text:""},{click_event:{action:"change_page",page:57},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 57"},text:""},{click_event:{action:"change_page",page:58},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 58"},text:""},{click_event:{action:"change_page",page:59},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 59"},text:""},{click_event:{action:"change_page",page:60},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 60"},text:""},{text:"

"},{click_event:{action:"change_page",page:61},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 61"},text:""},{click_event:{action:"change_page",page:62},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 62"},text:""},{click_event:{action:"change_page",page:63},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 63"},text:""},{click_event:{action:"change_page",page:64},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 64"},text:""},{click_event:{action:"change_page",page:65},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 65"},text:""},{click_event:{action:"change_page",page:66},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 66"},text:""},{click_event:{action:"change_page",page:67},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 67"},text:""},{text:"

"},{click_event:{action:"change_page",page:68},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 68"},text:""},{click_event:{action:"change_page",page:69},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 69"},text:""},{click_event:{action:"change_page",page:70},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 70"},text:""},{click_event:{action:"change_page",page:71},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 71"},text:""},{click_event:{action:"change_page",page:72},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 72"},text:""},{click_event:{action:"change_page",page:74},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 74"},text:""},{click_event:{action:"change_page",page:75},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 75"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"     Meals"},{text:"



"},{click_event:{action:"change_page",page:78},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 78"},text:""}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"  Ingredients"},{text:"



"},{click_event:{action:"change_page",page:80},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 80"},text:""},{click_event:{action:"change_page",page:81},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 81"},text:""},{click_event:{action:"change_page",page:82},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 82"},text:""},{click_event:{action:"change_page",page:83},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 83"},text:""},{click_event:{action:"change_page",page:85},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 85"},text:""},{click_event:{action:"change_page",page:86},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 86"},text:""},{click_event:{action:"change_page",page:87},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 87"},text:""},{text:"

"},{click_event:{action:"change_page",page:88},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 88"},text:""},{click_event:{action:"change_page",page:89},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 89"},text:""},{click_event:{action:"change_page",page:90},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 90"},text:""},{click_event:{action:"change_page",page:91},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 91"},text:""},{click_event:{action:"change_page",page:92},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 92"},text:""},{click_event:{action:"change_page",page:93},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 93"},text:""},{click_event:{action:"change_page",page:94},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 94"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"     Tools"},{text:"



"},{click_event:{action:"change_page",page:95},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 95"},text:""},{click_event:{action:"change_page",page:96},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 96"},text:""},{click_event:{action:"change_page",page:97},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 97"},text:""},{click_event:{action:"change_page",page:98},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 98"},text:""},{click_event:{action:"change_page",page:99},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 99"},text:""},{click_event:{action:"change_page",page:100},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 100"},text:""},{click_event:{action:"change_page",page:101},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 101"},text:""},{text:"

"},{click_event:{action:"change_page",page:102},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 102"},text:""},{click_event:{action:"change_page",page:103},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 103"},text:""},{click_event:{action:"change_page",page:104},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 104"},text:""},{click_event:{action:"change_page",page:105},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 105"},text:""},{click_event:{action:"change_page",page:106},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 106"},text:""},{click_event:{action:"change_page",page:107},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 107"},text:""}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"  Equipements"},{text:"



"},{click_event:{action:"change_page",page:108},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 108"},text:""},{click_event:{action:"change_page",page:109},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 109"},text:""}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"  Workstation"},{text:"



"},{click_event:{action:"change_page",page:110},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_text",value:"Go to page 110"},text:""}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"   Apple Pie
"},{text:"
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:wheat"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:wheat"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:wheat"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:apple"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:apple"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:apple"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:10},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"apple_pie"},food:{nutrition:8,saturation:6},item_name:"Apple Pie",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:bread"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:sugar"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:81},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{custom_data:{ts_name:"pie_crust"},item_name:"Pie Crust",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:angler_pottery_sherd"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:sugar"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"   Apple Pie
"},{font:"minecraft:stwb",text:"     Slice
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:10},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"apple_pie"},food:{nutrition:8,saturation:6},item_name:"Apple Pie",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:bread"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:11},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"apple_pie_slice"},food:{nutrition:2,saturation:1.5},item_name:"Apple Pie Slice",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:bread"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:" Chocolate Pie
"},{text:"
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:cocoa_beans"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:cocoa_beans"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:cocoa_beans"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:milk_bucket"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:milk_bucket"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:milk_bucket"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:12},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{on_consume_effects:[{effects:[{amplifier:1,duration:3600,id:"minecraft:speed"}],type:"apply_effects"}]},custom_data:{ts_name:"chocolate_pie"},food:{nutrition:8,saturation:6},item_name:"Chocolate Pie",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:bread"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:sugar"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:81},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{custom_data:{ts_name:"pie_crust"},item_name:"Pie Crust",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:angler_pottery_sherd"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:sugar"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:" Chocolate Pie
"},{font:"minecraft:stwb",text:"     Slice
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:12},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{on_consume_effects:[{effects:[{amplifier:1,duration:3600,id:"minecraft:speed"}],type:"apply_effects"}]},custom_data:{ts_name:"chocolate_pie"},food:{nutrition:8,saturation:6},item_name:"Chocolate Pie",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:bread"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:13},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{on_consume_effects:[{effects:[{amplifier:1,duration:900,id:"minecraft:speed"}],type:"apply_effects"}]},custom_data:{ts_name:"chocolate_pie_slice"},food:{nutrition:2,saturation:1.5},item_name:"Chocolate Pie Slice",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:bread"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"Cherry Blossom
"},{font:"minecraft:stwb",text:"      Pie
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:milk_bucket"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:milk_bucket"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:milk_bucket"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:14},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{on_consume_effects:[{effects:[{amplifier:1,duration:3600,id:"minecraft:slow_falling"}],type:"apply_effects"}]},custom_data:{ts_name:"cherry_blossom_pie"},food:{nutrition:8,saturation:6},item_name:"Cherry Blossom Pie",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:bread"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:honeycomb"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:81},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{custom_data:{ts_name:"pie_crust"},item_name:"Pie Crust",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:angler_pottery_sherd"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:honeycomb"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"Cherry Blossom
"},{font:"minecraft:stwb",text:"   Pie Slice
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:14},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{on_consume_effects:[{effects:[{amplifier:1,duration:3600,id:"minecraft:slow_falling"}],type:"apply_effects"}]},custom_data:{ts_name:"cherry_blossom_pie"},food:{nutrition:8,saturation:6},item_name:"Cherry Blossom Pie",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:bread"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:15},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{on_consume_effects:[{effects:[{amplifier:1,duration:900,id:"minecraft:slow_falling"}],type:"apply_effects"}]},custom_data:{ts_name:"cherry_blossom_pie_slice"},food:{nutrition:2,saturation:1.5},item_name:"Cherry Blossom Pie Slice",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:bread"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"  Chorus Pie
"},{text:"
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:chorus_fruit"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:chorus_fruit"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:chorus_fruit"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:sugar"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:sugar"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:sugar"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:16},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{on_consume_effects:[{diameter:32,type:"teleport_randomly"}]},custom_data:{ts_name:"chorus_pie"},food:{nutrition:8,saturation:6},item_name:"Chorus Pie",max_stack_size:64,rarity:"common",use_cooldown:{cooldown_group:"chorus_pie",seconds:2.0}},count:1,id:"minecraft:bread"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:milk_bucket"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:81},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{custom_data:{ts_name:"pie_crust"},item_name:"Pie Crust",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:angler_pottery_sherd"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:milk_bucket"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"  Chorus Pie
"},{font:"minecraft:stwb",text:"     Slice
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:16},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{on_consume_effects:[{diameter:32,type:"teleport_randomly"}]},custom_data:{ts_name:"chorus_pie"},food:{nutrition:8,saturation:6},item_name:"Chorus Pie",max_stack_size:64,rarity:"common",use_cooldown:{cooldown_group:"chorus_pie",seconds:2.0}},count:1,id:"minecraft:bread"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:17},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{on_consume_effects:[{diameter:8,type:"teleport_randomly"}]},custom_data:{ts_name:"chorus_pie_slice"},food:{nutrition:2,saturation:1.5},item_name:"Chorus Pie Slice",max_stack_size:64,rarity:"common",use_cooldown:{cooldown_group:"chorus_pie",seconds:1.0}},count:1,id:"minecraft:bread"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"Glow Berry Pie
"},{text:"
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:glow_berries"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:glow_berries"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:glow_berries"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:sugar"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:sugar"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:sugar"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:18},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{on_consume_effects:[{effects:[{amplifier:0,duration:3600,id:"minecraft:glowing"}],type:"apply_effects"}]},custom_data:{ts_name:"glow_berry_pie"},food:{nutrition:8,saturation:6},item_name:"Glow Berry Pie",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:bread"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:milk_bucket"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:81},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{custom_data:{ts_name:"pie_crust"},item_name:"Pie Crust",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:angler_pottery_sherd"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:milk_bucket"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"Glow Berry Pie
"},{font:"minecraft:stwb",text:"     Slice
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:18},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{on_consume_effects:[{effects:[{amplifier:0,duration:3600,id:"minecraft:glowing"}],type:"apply_effects"}]},custom_data:{ts_name:"glow_berry_pie"},food:{nutrition:8,saturation:6},item_name:"Glow Berry Pie",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:bread"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:19},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{on_consume_effects:[{effects:[{amplifier:1,duration:900,id:"minecraft:glowing"}],type:"apply_effects"}]},custom_data:{ts_name:"glow_berry_pie_slice"},food:{nutrition:2,saturation:1.5},item_name:"Glow Berry Pie Slice",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:bread"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"  Sweet Berry
"},{font:"minecraft:stwb",text:"  Cheesecake
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:sweet_berries"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:sweet_berries"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:sweet_berries"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:sweet_berries"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:sweet_berries"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:sweet_berries"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:20},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{on_consume_effects:[{effects:[{amplifier:0,duration:3600,id:"minecraft:speed"}],type:"apply_effects"}]},custom_data:{ts_name:"sweet_berry_cheesecake"},food:{nutrition:8,saturation:6},item_name:"Sweet Berry Cheesecake",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:bread"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:milk_bucket"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:81},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{custom_data:{ts_name:"pie_crust"},item_name:"Pie Crust",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:angler_pottery_sherd"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:milk_bucket"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"  Sweet Berry
"},{font:"minecraft:stwb",text:"  Cheesecake
"},{font:"minecraft:stwb",text:"     Slice
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:20},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{on_consume_effects:[{effects:[{amplifier:0,duration:3600,id:"minecraft:speed"}],type:"apply_effects"}]},custom_data:{ts_name:"sweet_berry_cheesecake"},food:{nutrition:8,saturation:6},item_name:"Sweet Berry Cheesecake",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:bread"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:21},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{on_consume_effects:[{effects:[{amplifier:1,duration:900,id:"minecraft:speed"}],type:"apply_effects"}]},custom_data:{ts_name:"sweet_berry_cheesecake_slice"},food:{nutrition:2,saturation:1.5},item_name:"Sweet Berry Cheesecake Slice",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:bread"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:" Honeyed Apple
"},{text:"
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:apple"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:honey_bottle"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:22},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"honeyed_apple"},food:{nutrition:6,saturation:8.6},item_name:"Honeyed Apple",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:bread"},text:""},{text:"

"},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:" Honey Cookie
"},{text:"
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:wheat"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:honey_bottle"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:wheat"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:23},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"honey_cookie"},food:{nutrition:2,saturation:0.4},item_name:"Honey Cookie",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:bread"},text:""},{text:"

"},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"  Sweet Berry
"},{font:"minecraft:stwb",text:"    Cookie
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:wheat"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:sweet_berries"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:wheat"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:24},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"sweet_berry_cookie"},food:{nutrition:2,saturation:0.4},item_name:"Sweet Berry Cookie",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:bread"},text:""},{text:"

"},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"   Croissant
"},{text:"
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:wheat"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:80},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{on_consume_effects:[{type:"clear_all_effects"}]},custom_data:{ts_name:"butter"},food:{nutrition:2,saturation:1.2},item_name:"Butter",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:poisonous_potato"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:sugar"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:wheat"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:80},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{on_consume_effects:[{type:"clear_all_effects"}]},custom_data:{ts_name:"butter"},food:{nutrition:2,saturation:1.2},item_name:"Butter",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:poisonous_potato"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:sugar"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:25},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"croissant"},food:{nutrition:6,saturation:3.4},item_name:"Croissant",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:bread"},text:""},{text:"

"},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"  Sweet Roll
"},{text:"
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:wheat"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:sugar"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:26},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"sweet_roll"},food:{nutrition:8,saturation:12.8},item_name:"Sweet Roll",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:bread"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:80},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{on_consume_effects:[{type:"clear_all_effects"}]},custom_data:{ts_name:"butter"},food:{nutrition:2,saturation:1.2},item_name:"Butter",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:poisonous_potato"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"   Ice Cream
"},{text:"
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:snowball"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:sugar"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:27},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"ice_cream"},food:{nutrition:4,saturation:3.6},item_name:"Ice Cream",max_stack_size:16,rarity:"common"},count:1,id:"minecraft:bread"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:82},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"ice_cream_cone"},food:{nutrition:2,saturation:0.4},item_name:"Ice Cream Cone",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:bread"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"Melon Popsicle
"},{text:"
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:melon_slice"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:melon_slice"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:melon_slice"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:melon_slice"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:28},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"melon_popsicle"},food:{nutrition:3,saturation:0.5},item_name:"Melon Popsicle",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:bread"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:stick"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"  Apple Cider
"},{text:"
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:apple"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:apple"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:29},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{custom_data:{ts_name:"apple_cider"},item_name:"Apple Cider",max_stack_size:16,potion_contents:{custom_effects:[{amplifier:1,duration:1800,id:"minecraft:absorption"}]},rarity:"common"},count:1,id:"minecraft:potion"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:sugar"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:glass_bottle"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"  Apple Cider
"},{font:"minecraft:stwb",text:"     Horn
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:apple"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:apple"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:30},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{custom_data:{ts_name:"apple_cider_horn"},item_name:"Apple Cider Horn",max_stack_size:16,potion_contents:{custom_effects:[{amplifier:1,duration:1800,id:"minecraft:absorption"}]},rarity:"common",use_remainder:{id:"minecraft:goat_horn"}},count:1,id:"minecraft:potion"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:sugar"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:goat_horn"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"  Glow Berry
"},{font:"minecraft:stwb",text:"    Custard
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:glow_berries"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:milk_bucket"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:egg"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:31},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{custom_data:{ts_name:"glow_berry_custard"},item_name:"Glow Berry Custard",max_stack_size:16,potion_contents:{custom_effects:[{amplifier:0,duration:3600,id:"minecraft:glowing"}]},rarity:"common"},count:1,id:"minecraft:potion"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:sugar"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:glass_bottle"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"  Glow Berry
"},{font:"minecraft:stwb",text:" Custard Horn
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:glow_berries"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:milk_bucket"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:egg"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:32},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{custom_data:{ts_name:"glow_berry_custard_horn"},item_name:"Glow Berry Custard Horn",max_stack_size:16,potion_contents:{custom_effects:[{amplifier:0,duration:3600,id:"minecraft:glowing"}]},rarity:"common",use_remainder:{id:"minecraft:goat_horn"}},count:1,id:"minecraft:potion"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:sugar"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:goat_horn"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"   Hot Cocoa
"},{text:"
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:cocoa_beans"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:cocoa_beans"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:milk_bucket"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:33},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{custom_data:{ts_name:"hot_cocoa"},item_name:"Hot Cocoa",max_stack_size:16,potion_contents:{custom_effects:[{amplifier:0,duration:600,id:"minecraft:regeneration"}]},rarity:"common"},count:1,id:"minecraft:potion"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:sugar"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:glass_bottle"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"Hot Cocoa Horn
"},{text:"
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:cocoa_beans"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:cocoa_beans"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:milk_bucket"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:34},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{custom_data:{ts_name:"hot_cocoa_horn"},item_name:"Hot Cocoa Horn",max_stack_size:16,potion_contents:{custom_effects:[{amplifier:0,duration:600,id:"minecraft:regeneration"}]},rarity:"common",use_remainder:{id:"minecraft:goat_horn"}},count:1,id:"minecraft:potion"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:sugar"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:goat_horn"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"  Melon Juice
"},{text:"
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:melon_slice"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:melon_slice"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:melon_slice"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:35},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{custom_data:{ts_name:"melon_juice"},item_name:"Melon Juice",max_stack_size:16,potion_contents:{custom_effects:[{amplifier:0,id:"minecraft:instant_health"}]},rarity:"common"},count:1,id:"minecraft:potion"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:melon_slice"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:sugar"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:glass_bottle"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"  Melon Juice
"},{font:"minecraft:stwb",text:"     Horn
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:melon_slice"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:melon_slice"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:melon_slice"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:36},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{custom_data:{ts_name:"melon_juice_horn"},item_name:"Melon Juice Horn",max_stack_size:16,potion_contents:{custom_effects:[{amplifier:0,id:"minecraft:instant_health"}]},rarity:"common",use_remainder:{id:"minecraft:goat_horn"}},count:1,id:"minecraft:potion"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:melon_slice"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:sugar"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:goat_horn"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:" Magma Gelatin
"},{text:"
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:bucket"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:magma_cream"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:magma_cream"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:37},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{on_consume_effects:[{effects:[{amplifier:0,duration:300,id:"minecraft:nausea"},{amplifier:0,duration:6000,id:"minecraft:fire_resistance"}],type:"apply_effects"}]},custom_data:{ts_name:"magma_gelatin"},food:{can_always_eat:true,nutrition:1,saturation:6},item_name:"Magma Gelatin",max_stack_size:1,rarity:"common",use_remainder:{id:"minecraft:bucket"}},count:1,id:"minecraft:bread"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:magma_cream"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:blaze_powder"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:blaze_powder"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"Baked Tentacle
"},{font:"minecraft:stwb",text:"  On A Stick
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:93},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"cooked_tentacle"},food:{nutrition:4,saturation:3.8},item_name:"Cooked Tentacle",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:mojang_banner_pattern"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:93},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"cooked_tentacle"},food:{nutrition:4,saturation:3.8},item_name:"Cooked Tentacle",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:mojang_banner_pattern"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:38},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"baked_tentacle_on_a_stick"},food:{nutrition:14,saturation:16.8},item_name:"Baked Tentacle On A Stick",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:bread"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:stick"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"Baked Barnacle
"},{font:"minecraft:stwb",text:"  Thong On A
"},{font:"minecraft:stwb",text:"     Stick
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:94},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"cooked_barnacle_thong"},food:{nutrition:2,saturation:2.6},item_name:"Cooked Barnacle Thong",max_stack_size:64,rarity:"uncommon"},count:1,id:"minecraft:creeper_banner_pattern"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:stick"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:39},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{on_consume_effects:[{effects:[{duration:3600,id:"minecraft:water_breathing"}],type:"apply_effects"}]},custom_data:{ts_name:"baked_barnacle_thong_on_a_stick"},food:{nutrition:12,saturation:14.8},item_name:"Baked Barnacle Thong On A Stick",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:bread"},text:""},{text:"

"},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"  Beef Skewer
"},{text:"
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:cooked_beef"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:cooked_beef"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:40},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"beef_skewer"},food:{nutrition:16,saturation:25.6},item_name:"Beef Skewer",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:bread"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:stick"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"   Beef Stew
"},{text:"
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:bowl"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:cooked_beef"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:41},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"beef_stew"},food:{nutrition:10,saturation:12},item_name:"Beef Stew",max_stack_size:64,rarity:"common",use_remainder:{id:"minecraft:bowl"}},count:1,id:"minecraft:rabbit_stew"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:carrot"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:baked_potato"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"    Cheese
"},{text:"
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:milk_bucket"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:42},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"cheese"},food:{nutrition:8,saturation:5.6},item_name:"Cheese",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:bread"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:" Cheese Slice
"},{text:"
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:42},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"cheese"},food:{nutrition:8,saturation:5.6},item_name:"Cheese",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:bread"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:43},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"cheese_slice"},food:{nutrition:2,saturation:1.4},item_name:"Cheese Slice",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:piglin_banner_pattern"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"   Fried Egg
"},{text:"
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:44},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"fried_egg"},food:{nutrition:8,saturation:2.4},item_name:"Fried Egg",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:piglin_banner_pattern"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"  Fruit Salad
"},{text:"
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:bowl"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:apple"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:apple"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:melon_slice"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:melon_slice"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:45},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{on_consume_effects:[{effects:[{amplifier:0,duration:600,id:"minecraft:regeneration"}],type:"apply_effects"}]},custom_data:{ts_name:"fruit_salad"},food:{nutrition:18,saturation:7.6},item_name:"Fruit Salad",max_stack_size:64,rarity:"common",use_remainder:{id:"minecraft:bowl"}},count:1,id:"minecraft:bread"},text:""},{text:"

"},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:" Fungus Skewer
"},{font:"minecraft:stwb",text:"     (1/2)
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:46},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{on_consume_effects:[{effects:[{amplifier:0,duration:600,id:"minecraft:nausea"}],type:"apply_effects"}]},custom_data:{ts_name:"fungus_skewer"},food:{nutrition:5,saturation:6},item_name:"Fungus Skewer",max_stack_size:64,rarity:"common",use_remainder:{id:"minecraft:stick"}},count:1,id:"minecraft:bread"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:stick"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:" Fungus Skewer
"},{font:"minecraft:stwb",text:"     (2/2)
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:46},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{on_consume_effects:[{effects:[{amplifier:0,duration:600,id:"minecraft:nausea"}],type:"apply_effects"}]},custom_data:{ts_name:"fungus_skewer"},food:{nutrition:5,saturation:6},item_name:"Fungus Skewer",max_stack_size:64,rarity:"common",use_remainder:{id:"minecraft:stick"}},count:1,id:"minecraft:bread"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:stick"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"   Mushroom
"},{font:"minecraft:stwb",text:" Skewer (1/2)
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:48},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"mushroom_skewer"},food:{nutrition:6,saturation:7.2},item_name:"Mushroom Skewer",max_stack_size:64,rarity:"common",use_remainder:{id:"minecraft:stick"}},count:1,id:"minecraft:bread"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:stick"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"   Mushroom
"},{font:"minecraft:stwb",text:" Skewer (2/2)
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:48},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"mushroom_skewer"},food:{nutrition:6,saturation:7.2},item_name:"Mushroom Skewer",max_stack_size:64,rarity:"common",use_remainder:{id:"minecraft:stick"}},count:1,id:"minecraft:bread"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:stick"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:" Nether Salad
"},{text:"
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:bowl"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:50},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{on_consume_effects:[{effects:[{amplifier:0,duration:600,id:"minecraft:nausea"}],type:"apply_effects"}]},custom_data:{ts_name:"nether_salad"},food:{nutrition:5,saturation:6},item_name:"Nether Salad",max_stack_size:64,rarity:"common",use_remainder:{id:"minecraft:bowl"}},count:1,id:"minecraft:bread"},text:""},{text:"

"},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:" Potato Fries
"},{text:"
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:baked_potato"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:51},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"potato_fries"},food:{nutrition:1.5,saturation:1.5},item_name:"Potato Fries",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:bread"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"Stuffed Potato
"},{text:"
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:baked_potato"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:cooked_beef"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:52},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"stuffed_potato"},food:{nutrition:8,saturation:10.8},item_name:"Stuffed Potato",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:bread"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:carrot"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:milk_bucket"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:" Warped Mutton
"},{text:"
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:53},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{on_consume_effects:[{effects:[{amplifier:0,duration:300,id:"minecraft:nausea"}],type:"apply_effects"}]},custom_data:{ts_name:"warped_mutton"},food:{nutrition:6,saturation:11},item_name:"Warped Mutton",max_stack_size:64,rarity:"common",use_remainder:{id:"minecraft:bowl"}},count:1,id:"minecraft:bread"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:bowl"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:cooked_mutton"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"   Kelp Roll
"},{text:"
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:92},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"cooked_rice"},food:{nutrition:2,saturation:3.2},item_name:"Cooked Rice",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:field_masoned_banner_pattern"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:carrot"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:92},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"cooked_rice"},food:{nutrition:2,saturation:3.2},item_name:"Cooked Rice",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:field_masoned_banner_pattern"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:dried_kelp"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:dried_kelp"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:dried_kelp"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:54},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"kelp_roll"},food:{nutrition:10,saturation:12.6},item_name:"Kelp Roll",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:bread"},text:""},{text:"

"},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"   Kelp Roll
"},{font:"minecraft:stwb",text:"     Slice
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:54},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"kelp_roll"},food:{nutrition:10,saturation:12.6},item_name:"Kelp Roll",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:bread"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:55},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"kelp_roll_slice"},food:{nutrition:2.5,saturation:6.2},item_name:"Kelp Roll Slice",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:bread"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"  Salmon Roll
"},{text:"
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:90},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"raw_salmon_slice"},food:{nutrition:1,saturation:0.8},item_name:"Raw Salmon Slice",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:bordure_indented_banner_pattern"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:90},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"raw_salmon_slice"},food:{nutrition:1,saturation:0.8},item_name:"Raw Salmon Slice",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:bordure_indented_banner_pattern"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:56},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"salmon_roll"},food:{nutrition:7,saturation:9.4},item_name:"Salmon Roll",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:bread"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:92},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"cooked_rice"},food:{nutrition:2,saturation:3.2},item_name:"Cooked Rice",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:field_masoned_banner_pattern"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"   Cod Roll
"},{text:"
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:89},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"raw_cod_slice"},food:{nutrition:1,saturation:0.8},item_name:"Raw Cod Slice",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:flower_banner_pattern"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:89},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"raw_cod_slice"},food:{nutrition:1,saturation:0.8},item_name:"Raw Cod Slice",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:flower_banner_pattern"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:57},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"cod_roll"},food:{nutrition:7,saturation:9.4},item_name:"Cod Roll",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:bread"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:92},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"cooked_rice"},food:{nutrition:2,saturation:3.2},item_name:"Cooked Rice",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:field_masoned_banner_pattern"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:" Guardian Roll
"},{text:"
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{on_consume_effects:[{effects:[{duration:600,id:"minecraft:mining_fatigue"}],type:"apply_effects"}]},custom_data:{ts_name:"guardian_tail"},food:{nutrition:2,saturation:1.6},item_name:"Guardian Tail",max_stack_size:64,rarity:"rare"},count:1,id:"minecraft:flow_banner_pattern"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{on_consume_effects:[{effects:[{duration:600,id:"minecraft:mining_fatigue"}],type:"apply_effects"}]},custom_data:{ts_name:"guardian_tail"},food:{nutrition:2,saturation:1.6},item_name:"Guardian Tail",max_stack_size:64,rarity:"rare"},count:1,id:"minecraft:flow_banner_pattern"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:58},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"guardian_roll"},food:{nutrition:8,saturation:10.2},item_name:"Guardian Roll",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:bread"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:92},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"cooked_rice"},food:{nutrition:2,saturation:3.2},item_name:"Cooked Rice",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:field_masoned_banner_pattern"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:" Egg Sandwich
"},{text:"
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:bread"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:44},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"fried_egg"},food:{nutrition:8,saturation:2.4},item_name:"Fried Egg",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:piglin_banner_pattern"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:59},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"egg_sandwich"},food:{nutrition:11,saturation:16.4},item_name:"Egg Sandwich",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:bread"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:44},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"fried_egg"},food:{nutrition:8,saturation:2.4},item_name:"Fried Egg",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:piglin_banner_pattern"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"Bacon Sandwich
"},{text:"
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:bread"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:88},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"cooked_bacon"},food:{nutrition:4,saturation:6.4},item_name:"Cooked Bacon",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:skull_banner_pattern"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:60},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"bacon_sandwich"},food:{nutrition:14,saturation:20.8},item_name:"Bacon Sandwich",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:bread"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:88},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"cooked_bacon"},food:{nutrition:4,saturation:6.4},item_name:"Cooked Bacon",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:skull_banner_pattern"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:kelp"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:" Rabbit Burger
"},{text:"
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:bread"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:cooked_rabbit"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:61},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"rabbit_burger"},food:{nutrition:10,saturation:17.2},item_name:"Rabbit Burger",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:bread"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:carrot"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:kelp"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"    Chicken
"},{font:"minecraft:stwb",text:"   Sandwich
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:bread"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:cooked_chicken"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:62},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"chicken_sandwich"},food:{nutrition:12,saturation:19.0},item_name:"Chicken Sandwich",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:bread"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:carrot"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:kelp"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"  Mutton Wrap
"},{text:"
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:bread"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:cooked_mutton"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:63},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"mutton_wrap"},food:{nutrition:14,saturation:24.4},item_name:"Mutton Wrap",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:bread"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:92},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"cooked_rice"},food:{nutrition:2,saturation:3.2},item_name:"Cooked Rice",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:field_masoned_banner_pattern"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:kelp"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"   Hamburger
"},{text:"
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:bread"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:cooked_beef"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:64},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"hamburger"},food:{nutrition:11,saturation:16.4},item_name:"Hamburger",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:bread"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:kelp"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:" Cheeseburger
"},{text:"
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:bread"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:cooked_beef"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:65},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"cheeseburger"},food:{nutrition:14,saturation:20.8},item_name:"Cheeseburger",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:bread"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:43},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"cheese_slice"},food:{nutrition:2,saturation:1.4},item_name:"Cheese Slice",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:piglin_banner_pattern"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:kelp"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"  Fish Burger
"},{text:"
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:bread"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:cooked_cod"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:66},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"fish_burger"},food:{nutrition:13,saturation:18.4},item_name:"Fish Burger",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:bread"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:kelp"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"   Sea Stew
"},{text:"
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:bowl"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:93},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"cooked_tentacle"},food:{nutrition:4,saturation:3.8},item_name:"Cooked Tentacle",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:mojang_banner_pattern"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:67},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"sea_stew"},food:{nutrition:12,saturation:10.2},item_name:"Sea Stew",max_stack_size:64,rarity:"common",use_remainder:{id:"minecraft:bowl"}},count:1,id:"minecraft:bread"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:cooked_cod"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:" Seagrass Soup
"},{text:"
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:bowl"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:seagrass"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:68},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"seagrass_soup"},food:{nutrition:4,saturation:3.6},item_name:"Seagrass Soup",max_stack_size:64,rarity:"common",use_remainder:{id:"minecraft:bowl"}},count:1,id:"minecraft:bread"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:seagrass"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"Squid Sandwich
"},{text:"
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:bread"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:93},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"cooked_tentacle"},food:{nutrition:4,saturation:3.8},item_name:"Cooked Tentacle",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:mojang_banner_pattern"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:69},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"squid_sandwich"},food:{nutrition:14,saturation:19.6},item_name:"Squid Sandwich",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:bread"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:93},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"cooked_tentacle"},food:{nutrition:4,saturation:3.8},item_name:"Cooked Tentacle",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:mojang_banner_pattern"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:kelp"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"    Stuffed
"},{font:"minecraft:stwb",text:"Nautilus Shell
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:nautilus_shell"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:carrot"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:70},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"stuffed_nautilus_shell"},food:{nutrition:12,saturation:16.4},item_name:"Stuffed Nautilus Shell",max_stack_size:64,rarity:"common",use_remainder:{id:"minecraft:nautilus_shell"}},count:1,id:"minecraft:bread"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:kelp"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:baked_potato"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:" Seafood Pasta
"},{text:"
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:bowl"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:86},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"pasta"},food:{nutrition:2,saturation:1.4},item_name:"Pasta",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:sheaf_pottery_sherd"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:90},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"raw_salmon_slice"},food:{nutrition:1,saturation:0.8},item_name:"Raw Salmon Slice",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:bordure_indented_banner_pattern"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:71},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"seafood_pasta"},food:{nutrition:10,saturation:14.2},item_name:"Seafood Pasta",max_stack_size:64,rarity:"common",use_remainder:{id:"minecraft:bowl"}},count:1,id:"minecraft:bread"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:dried_kelp"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:seagrass"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"   Ink Pasta
"},{font:"minecraft:stwb",text:"     (1/2)
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:bowl"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:86},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"pasta"},food:{nutrition:2,saturation:1.4},item_name:"Pasta",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:sheaf_pottery_sherd"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:89},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"raw_cod_slice"},food:{nutrition:1,saturation:0.8},item_name:"Raw Cod Slice",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:flower_banner_pattern"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:72},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"ink_pasta"},food:{nutrition:8,saturation:9.4},item_name:"Ink Pasta",max_stack_size:64,rarity:"common",use_remainder:{id:"minecraft:bowl"}},count:1,id:"minecraft:bread"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:ink_sac"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:beetroot"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"   Ink Pasta
"},{font:"minecraft:stwb",text:"     (2/2)
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:bowl"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:86},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"pasta"},food:{nutrition:2,saturation:1.4},item_name:"Pasta",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:sheaf_pottery_sherd"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:90},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"raw_salmon_slice"},food:{nutrition:1,saturation:0.8},item_name:"Raw Salmon Slice",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:bordure_indented_banner_pattern"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:72},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"ink_pasta"},food:{nutrition:8,saturation:9.4},item_name:"Ink Pasta",max_stack_size:64,rarity:"common",use_remainder:{id:"minecraft:bowl"}},count:1,id:"minecraft:bread"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:ink_sac"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:beetroot"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"Beetroot Pasta
"},{text:"
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:bowl"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:86},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"pasta"},food:{nutrition:2,saturation:1.4},item_name:"Pasta",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:sheaf_pottery_sherd"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:74},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"beetroot_pasta"},food:{nutrition:10,saturation:10.6},item_name:"Beetroot Pasta",max_stack_size:64,rarity:"common",use_remainder:{id:"minecraft:bowl"}},count:1,id:"minecraft:bread"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:beetroot"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:beetroot"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"   Vegetable
"},{font:"minecraft:stwb",text:" Noodles (1/3)
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:bowl"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:86},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"pasta"},food:{nutrition:2,saturation:1.4},item_name:"Pasta",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:sheaf_pottery_sherd"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:carrot"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:75},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"vegetable_noodles"},food:{nutrition:12,saturation:12.6},item_name:"Vegetable Noodles",max_stack_size:64,rarity:"common",use_remainder:{id:"minecraft:bowl"}},count:1,id:"minecraft:bread"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:kelp"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:potato"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"   Vegetable
"},{font:"minecraft:stwb",text:" Noodles (2/3)
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:bowl"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:86},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"pasta"},food:{nutrition:2,saturation:1.4},item_name:"Pasta",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:sheaf_pottery_sherd"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:carrot"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:75},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"vegetable_noodles"},food:{nutrition:12,saturation:12.6},item_name:"Vegetable Noodles",max_stack_size:64,rarity:"common",use_remainder:{id:"minecraft:bowl"}},count:1,id:"minecraft:bread"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:kelp"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:carrot"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"   Vegetable
"},{font:"minecraft:stwb",text:" Noodles (3/3)
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:bowl"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:86},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"pasta"},food:{nutrition:2,saturation:1.4},item_name:"Pasta",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:sheaf_pottery_sherd"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:carrot"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:75},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"vegetable_noodles"},food:{nutrition:12,saturation:12.6},item_name:"Vegetable Noodles",max_stack_size:64,rarity:"common",use_remainder:{id:"minecraft:bowl"}},count:1,id:"minecraft:bread"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:kelp"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:beetroot"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"  Noodle Soup
"},{font:"minecraft:stwb",text:"     (1/2)
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:bowl"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:86},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"pasta"},food:{nutrition:2,saturation:1.4},item_name:"Pasta",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:sheaf_pottery_sherd"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:88},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"cooked_bacon"},food:{nutrition:4,saturation:6.4},item_name:"Cooked Bacon",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:skull_banner_pattern"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:78},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"noodle_soup"},food:{nutrition:12,saturation:16.2},item_name:"Noodle Soup",max_stack_size:64,rarity:"common",use_remainder:{id:"minecraft:bowl"}},count:1,id:"minecraft:bread"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:egg"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:dried_kelp"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"  Noodle Soup
"},{font:"minecraft:stwb",text:"     (2/2)
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:bowl"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:86},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"pasta"},food:{nutrition:2,saturation:1.4},item_name:"Pasta",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:sheaf_pottery_sherd"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:cooked_porkchop"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:78},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"noodle_soup"},food:{nutrition:12,saturation:16.2},item_name:"Noodle Soup",max_stack_size:64,rarity:"common",use_remainder:{id:"minecraft:bowl"}},count:1,id:"minecraft:bread"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:egg"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:dried_kelp"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"    Butter
"},{text:"
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:milk_bucket"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:80},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{on_consume_effects:[{type:"clear_all_effects"}]},custom_data:{ts_name:"butter"},food:{nutrition:2,saturation:1.2},item_name:"Butter",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:poisonous_potato"},text:""},{text:"

"},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"   Pie Crust
"},{text:"
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:wheat"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:80},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{on_consume_effects:[{type:"clear_all_effects"}]},custom_data:{ts_name:"butter"},food:{nutrition:2,saturation:1.2},item_name:"Butter",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:poisonous_potato"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:wheat"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:wheat"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:81},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{custom_data:{ts_name:"pie_crust"},item_name:"Pie Crust",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:angler_pottery_sherd"},text:""},{text:"

"},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"Ice Cream Cone
"},{text:"
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:wheat"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:wheat"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:82},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"ice_cream_cone"},food:{nutrition:2,saturation:0.4},item_name:"Ice Cream Cone",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:bread"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:wheat"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"  Wheat Dough
"},{font:"minecraft:stwb",text:"     (1/2)
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:wheat"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:wheat"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:83},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"wheat_dough"},food:{nutrition:2,saturation:0.8},item_name:"Wheat Dough",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:snort_pottery_sherd"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:wheat"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:egg"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"  Wheat Dough
"},{font:"minecraft:stwb",text:"     (2/2)
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:wheat"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:wheat"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:83},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"wheat_dough"},food:{nutrition:2,saturation:0.8},item_name:"Wheat Dough",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:snort_pottery_sherd"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:wheat"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:water_bucket"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"   Raw Pasta
"},{text:"
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:83},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"wheat_dough"},food:{nutrition:2,saturation:0.8},item_name:"Wheat Dough",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:snort_pottery_sherd"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:85},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"raw_pasta"},food:{nutrition:1,saturation:0.4},item_name:"Raw Pasta",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:skull_pottery_sherd"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"     Pasta
"},{text:"
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:85},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"raw_pasta"},food:{nutrition:1,saturation:0.4},item_name:"Raw Pasta",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:skull_pottery_sherd"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:86},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"pasta"},food:{nutrition:2,saturation:1.4},item_name:"Pasta",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:sheaf_pottery_sherd"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"   Raw Bacon
"},{text:"
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:porkchop"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:87},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"raw_bacon"},food:{nutrition:1.5,saturation:0.3},item_name:"Raw Bacon",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:archer_pottery_sherd"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:" Cooked Bacon
"},{text:"
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:87},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"raw_bacon"},food:{nutrition:1.5,saturation:0.3},item_name:"Raw Bacon",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:archer_pottery_sherd"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:88},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"cooked_bacon"},food:{nutrition:4,saturation:6.4},item_name:"Cooked Bacon",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:skull_banner_pattern"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:" Raw Cod Slice
"},{text:"
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:cod"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:89},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"raw_cod_slice"},food:{nutrition:1,saturation:0.8},item_name:"Raw Cod Slice",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:flower_banner_pattern"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"  Raw Salmon
"},{font:"minecraft:stwb",text:"     Slice
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:salmon"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:90},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"raw_salmon_slice"},food:{nutrition:1,saturation:0.8},item_name:"Raw Salmon Slice",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:bordure_indented_banner_pattern"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"     Rice
"},{text:"
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:wheat"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:91},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{custom_data:{ts_name:"rice"},item_name:"Rice",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:arms_up_pottery_sherd"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"  Cooked Rice
"},{text:"
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:91},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{custom_data:{ts_name:"rice"},item_name:"Rice",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:arms_up_pottery_sherd"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:92},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"cooked_rice"},food:{nutrition:2,saturation:3.2},item_name:"Cooked Rice",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:field_masoned_banner_pattern"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"    Cooked
"},{font:"minecraft:stwb",text:"   Tentacle
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"tentacle"},food:{nutrition:2,saturation:1.4},item_name:"Tentacle",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:blade_pottery_sherd"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:93},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"cooked_tentacle"},food:{nutrition:4,saturation:3.8},item_name:"Cooked Tentacle",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:mojang_banner_pattern"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"    Cooked
"},{font:"minecraft:stwb",text:"Barnacle Thong
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{on_consume_effects:[{effects:[{duration:250,id:"minecraft:nausea"}],type:"apply_effects"}]},custom_data:{ts_name:"barnacle_thong"},food:{nutrition:1,saturation:0.8},item_name:"Barnacle Thong",max_stack_size:64,rarity:"uncommon"},count:1,id:"minecraft:guster_banner_pattern"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:94},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{consumable:{},custom_data:{ts_name:"cooked_barnacle_thong"},food:{nutrition:2,saturation:2.6},item_name:"Cooked Barnacle Thong",max_stack_size:64,rarity:"uncommon"},count:1,id:"minecraft:creeper_banner_pattern"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"   Netherite
"},{font:"minecraft:stwb",text:"     Knife
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:95},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{attribute_modifiers:[{amount:3.5,display:{type:"override",value:{color:"dark_green",fallback:"%s %s",translate:"attribute.modifier.equals.0",type:"translatable",with:[{text:" 4.5"},{fallback:"Attack Damage",translate:"attribute.name.attack_damage",type:"translatable"}]}},id:"tasty_supplies:netherite_knife_damage",operation:"add_value",slot:"mainhand",type:"attack_damage"},{amount:-1.7,display:{type:"override",value:{color:"dark_green",fallback:"%s %s",translate:"attribute.modifier.equals.0",type:"translatable",with:[{text:" 2.3"},{fallback:"Attack Speed",translate:"attribute.name.attack_speed",type:"translatable"}]}},id:"tasty_supplies:netherite_knife_speed",operation:"add_value",slot:"mainhand",type:"attack_speed"}],custom_data:{ts_cutting_tool:"knife",ts_name:"netherite_knife"},item_name:"Netherite Knife",max_damage:2032,max_stack_size:1,rarity:"common",weapon:{}},count:1,id:"minecraft:wooden_sword"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:" Diamond Knife
"},{text:"
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:diamond"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:stick"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:96},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{attribute_modifiers:[{amount:3.0,display:{type:"override",value:{color:"dark_green",fallback:"%s %s",translate:"attribute.modifier.equals.0",type:"translatable",with:[{text:" 4"},{fallback:"Attack Damage",translate:"attribute.name.attack_damage",type:"translatable"}]}},id:"tasty_supplies:diamond_knife_damage",operation:"add_value",slot:"mainhand",type:"attack_damage"},{amount:-1.7,display:{type:"override",value:{color:"dark_green",fallback:"%s %s",translate:"attribute.modifier.equals.0",type:"translatable",with:[{text:" 2.3"},{fallback:"Attack Speed",translate:"attribute.name.attack_speed",type:"translatable"}]}},id:"tasty_supplies:diamond_knife_speed",operation:"add_value",slot:"mainhand",type:"attack_speed"}],custom_data:{ts_cutting_tool:"knife",ts_name:"diamond_knife"},item_name:"Diamond Knife",max_damage:1561,max_stack_size:1,rarity:"common",weapon:{}},count:1,id:"minecraft:disc_fragment_5"},text:""},{text:"

"},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:" Golden Knife
"},{text:"
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:gold_ingot"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:stick"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:97},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{attribute_modifiers:[{amount:1.0,display:{type:"override",value:{color:"dark_green",fallback:"%s %s",translate:"attribute.modifier.equals.0",type:"translatable",with:[{text:" 2"},{fallback:"Attack Damage",translate:"attribute.name.attack_damage",type:"translatable"}]}},id:"tasty_supplies:golden_knife_damage",operation:"add_value",slot:"mainhand",type:"attack_damage"},{amount:-1.7,display:{type:"override",value:{color:"dark_green",fallback:"%s %s",translate:"attribute.modifier.equals.0",type:"translatable",with:[{text:" 2.3"},{fallback:"Attack Speed",translate:"attribute.name.attack_speed",type:"translatable"}]}},id:"tasty_supplies:golden_knife_speed",operation:"add_value",slot:"mainhand",type:"attack_speed"}],custom_data:{ts_cutting_tool:"knife",ts_name:"golden_knife"},item_name:"Golden Knife",max_damage:32,max_stack_size:1,rarity:"common",weapon:{}},count:1,id:"minecraft:wooden_sword"},text:""},{text:"

"},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"  Iron Knife
"},{text:"
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:iron_ingot"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:stick"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:98},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{attribute_modifiers:[{amount:2.5,display:{type:"override",value:{color:"dark_green",fallback:"%s %s",translate:"attribute.modifier.equals.0",type:"translatable",with:[{text:" 3.5"},{fallback:"Attack Damage",translate:"attribute.name.attack_damage",type:"translatable"}]}},id:"tasty_supplies:iron_knife_damage",operation:"add_value",slot:"mainhand",type:"attack_damage"},{amount:-1.7,display:{type:"override",value:{color:"dark_green",fallback:"%s %s",translate:"attribute.modifier.equals.0",type:"translatable",with:[{text:" 2.3"},{fallback:"Attack Speed",translate:"attribute.name.attack_speed",type:"translatable"}]}},id:"tasty_supplies:iron_knife_speed",operation:"add_value",slot:"mainhand",type:"attack_speed"}],custom_data:{ts_cutting_tool:"knife",ts_name:"iron_knife"},item_name:"Iron Knife",max_damage:250,max_stack_size:1,rarity:"common",weapon:{}},count:1,id:"minecraft:wooden_sword"},text:""},{text:"

"},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:" Copper Knife
"},{text:"
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:copper_ingot"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:stick"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:99},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{attribute_modifiers:[{amount:2.0,display:{type:"override",value:{color:"dark_green",fallback:"%s %s",translate:"attribute.modifier.equals.0",type:"translatable",with:[{text:" 3"},{fallback:"Attack Damage",translate:"attribute.name.attack_damage",type:"translatable"}]}},id:"tasty_supplies:copper_knife_damage",operation:"add_value",slot:"mainhand",type:"attack_damage"},{amount:-1.7,display:{type:"override",value:{color:"dark_green",fallback:"%s %s",translate:"attribute.modifier.equals.0",type:"translatable",with:[{text:" 2.3"},{fallback:"Attack Speed",translate:"attribute.name.attack_speed",type:"translatable"}]}},id:"tasty_supplies:copper_knife_speed",operation:"add_value",slot:"mainhand",type:"attack_speed"}],custom_data:{ts_cutting_tool:"knife",ts_name:"copper_knife"},item_name:"Copper Knife",max_damage:190,max_stack_size:1,rarity:"common",weapon:{}},count:1,id:"minecraft:wooden_sword"},text:""},{text:"

"},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"  Flint Knife
"},{text:"
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:flint"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:stick"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:100},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{attribute_modifiers:[{amount:2.0,display:{type:"override",value:{color:"dark_green",fallback:"%s %s",translate:"attribute.modifier.equals.0",type:"translatable",with:[{text:" 3"},{fallback:"Attack Damage",translate:"attribute.name.attack_damage",type:"translatable"}]}},id:"tasty_supplies:flint_knife_damage",operation:"add_value",slot:"mainhand",type:"attack_damage"},{amount:-1.7,display:{type:"override",value:{color:"dark_green",fallback:"%s %s",translate:"attribute.modifier.equals.0",type:"translatable",with:[{text:" 2.3"},{fallback:"Attack Speed",translate:"attribute.name.attack_speed",type:"translatable"}]}},id:"tasty_supplies:flint_knife_speed",operation:"add_value",slot:"mainhand",type:"attack_speed"}],custom_data:{ts_cutting_tool:"knife",ts_name:"flint_knife"},item_name:"Flint Knife",max_damage:131,max_stack_size:1,rarity:"common",weapon:{}},count:1,id:"minecraft:wooden_sword"},text:""},{text:"

"},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"   Netherite
"},{font:"minecraft:stwb",text:"    Cleaver
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:101},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{attribute_modifiers:[{amount:8.0,display:{type:"override",value:{color:"dark_green",fallback:"%s %s",translate:"attribute.modifier.equals.0",type:"translatable",with:[{text:" 9"},{fallback:"Attack Damage",translate:"attribute.name.attack_damage",type:"translatable"}]}},id:"tasty_supplies:netherite_cleaver_damage",operation:"add_value",slot:"mainhand",type:"attack_damage"},{amount:-2.8,display:{type:"override",value:{color:"dark_green",fallback:"%s %s",translate:"attribute.modifier.equals.0",type:"translatable",with:[{text:" 1.2"},{fallback:"Attack Speed",translate:"attribute.name.attack_speed",type:"translatable"}]}},id:"tasty_supplies:netherite_cleaver_speed",operation:"add_value",slot:"mainhand",type:"attack_speed"}],custom_data:{ts_cutting_tool:"cleaver",ts_name:"netherite_cleaver"},item_name:"Netherite Cleaver",max_damage:3046,max_stack_size:1,rarity:"common",weapon:{}},count:1,id:"minecraft:wooden_sword"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"    Diamond
"},{font:"minecraft:stwb",text:"    Cleaver
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:diamond"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:diamond"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:diamond"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:diamond"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:102},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{attribute_modifiers:[{amount:7.0,display:{type:"override",value:{color:"dark_green",fallback:"%s %s",translate:"attribute.modifier.equals.0",type:"translatable",with:[{text:" 8"},{fallback:"Attack Damage",translate:"attribute.name.attack_damage",type:"translatable"}]}},id:"tasty_supplies:diamond_cleaver_damage",operation:"add_value",slot:"mainhand",type:"attack_damage"},{amount:-2.8,display:{type:"override",value:{color:"dark_green",fallback:"%s %s",translate:"attribute.modifier.equals.0",type:"translatable",with:[{text:" 1.2"},{fallback:"Attack Speed",translate:"attribute.name.attack_speed",type:"translatable"}]}},id:"tasty_supplies:diamond_cleaver_speed",operation:"add_value",slot:"mainhand",type:"attack_speed"}],custom_data:{ts_cutting_tool:"cleaver",ts_name:"diamond_cleaver"},item_name:"Diamond Cleaver",max_damage:2341,max_stack_size:1,rarity:"common",weapon:{}},count:1,id:"minecraft:echo_shard"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:stick"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"Golden Cleaver
"},{text:"
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:gold_ingot"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:gold_ingot"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:gold_ingot"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:gold_ingot"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:103},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{attribute_modifiers:[{amount:5.0,display:{type:"override",value:{color:"dark_green",fallback:"%s %s",translate:"attribute.modifier.equals.0",type:"translatable",with:[{text:" 6"},{fallback:"Attack Damage",translate:"attribute.name.attack_damage",type:"translatable"}]}},id:"tasty_supplies:golden_cleaver_damage",operation:"add_value",slot:"mainhand",type:"attack_damage"},{amount:-2.8,display:{type:"override",value:{color:"dark_green",fallback:"%s %s",translate:"attribute.modifier.equals.0",type:"translatable",with:[{text:" 1.2"},{fallback:"Attack Speed",translate:"attribute.name.attack_speed",type:"translatable"}]}},id:"tasty_supplies:golden_cleaver_speed",operation:"add_value",slot:"mainhand",type:"attack_speed"}],custom_data:{ts_cutting_tool:"cleaver",ts_name:"golden_cleaver"},item_name:"Golden Cleaver",max_damage:48,max_stack_size:1,rarity:"common",weapon:{}},count:1,id:"minecraft:wooden_sword"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:stick"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:" Iron Cleaver
"},{text:"
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:iron_ingot"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:iron_ingot"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:iron_ingot"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:iron_ingot"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:104},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{attribute_modifiers:[{amount:7.0,display:{type:"override",value:{color:"dark_green",fallback:"%s %s",translate:"attribute.modifier.equals.0",type:"translatable",with:[{text:" 8"},{fallback:"Attack Damage",translate:"attribute.name.attack_damage",type:"translatable"}]}},id:"tasty_supplies:iron_cleaver_damage",operation:"add_value",slot:"mainhand",type:"attack_damage"},{amount:-2.9,display:{type:"override",value:{color:"dark_green",fallback:"%s %s",translate:"attribute.modifier.equals.0",type:"translatable",with:[{text:" 1.1"},{fallback:"Attack Speed",translate:"attribute.name.attack_speed",type:"translatable"}]}},id:"tasty_supplies:iron_cleaver_speed",operation:"add_value",slot:"mainhand",type:"attack_speed"}],custom_data:{ts_cutting_tool:"cleaver",ts_name:"iron_cleaver"},item_name:"Iron Cleaver",max_damage:375,max_stack_size:1,rarity:"common",weapon:{}},count:1,id:"minecraft:wooden_sword"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:stick"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"Copper Cleaver
"},{text:"
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:copper_ingot"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:copper_ingot"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:copper_ingot"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:copper_ingot"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:105},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{attribute_modifiers:[{amount:7.0,display:{type:"override",value:{color:"dark_green",fallback:"%s %s",translate:"attribute.modifier.equals.0",type:"translatable",with:[{text:" 8"},{fallback:"Attack Damage",translate:"attribute.name.attack_damage",type:"translatable"}]}},id:"tasty_supplies:copper_cleaver_damage",operation:"add_value",slot:"mainhand",type:"attack_damage"},{amount:-3.0,display:{type:"override",value:{color:"dark_green",fallback:"%s %s",translate:"attribute.modifier.equals.0",type:"translatable",with:[{text:" 1.0"},{fallback:"Attack Speed",translate:"attribute.name.attack_speed",type:"translatable"}]}},id:"tasty_supplies:copper_cleaver_speed",operation:"add_value",slot:"mainhand",type:"attack_speed"}],custom_data:{ts_cutting_tool:"cleaver",ts_name:"copper_cleaver"},item_name:"Copper Cleaver",max_damage:285,max_stack_size:1,rarity:"common",weapon:{}},count:1,id:"minecraft:wooden_sword"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:stick"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:" Stone Cleaver
"},{text:"
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:106},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{attribute_modifiers:[{amount:7.0,display:{type:"override",value:{color:"dark_green",fallback:"%s %s",translate:"attribute.modifier.equals.0",type:"translatable",with:[{text:" 8"},{fallback:"Attack Damage",translate:"attribute.name.attack_damage",type:"translatable"}]}},id:"tasty_supplies:stone_cleaver_damage",operation:"add_value",slot:"mainhand",type:"attack_damage"},{amount:-3.0,display:{type:"override",value:{color:"dark_green",fallback:"%s %s",translate:"attribute.modifier.equals.0",type:"translatable",with:[{text:" 1.0"},{fallback:"Attack Speed",translate:"attribute.name.attack_speed",type:"translatable"}]}},id:"tasty_supplies:stone_cleaver_speed",operation:"add_value",slot:"mainhand",type:"attack_speed"}],custom_data:{ts_cutting_tool:"cleaver",ts_name:"stone_cleaver"},item_name:"Stone Cleaver",max_damage:196,max_stack_size:1,rarity:"common",weapon:{}},count:1,id:"minecraft:wooden_sword"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:stick"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"Wooden Cleaver
"},{text:"
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:107},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{attribute_modifiers:[{amount:5.0,display:{type:"override",value:{color:"dark_green",fallback:"%s %s",translate:"attribute.modifier.equals.0",type:"translatable",with:[{text:" 6"},{fallback:"Attack Damage",translate:"attribute.name.attack_damage",type:"translatable"}]}},id:"tasty_supplies:wooden_cleaver_damage",operation:"add_value",slot:"mainhand",type:"attack_damage"},{amount:-3.0,display:{type:"override",value:{color:"dark_green",fallback:"%s %s",translate:"attribute.modifier.equals.0",type:"translatable",with:[{text:" 1.0"},{fallback:"Attack Speed",translate:"attribute.name.attack_speed",type:"translatable"}]}},id:"tasty_supplies:wooden_cleaver_speed",operation:"add_value",slot:"mainhand",type:"attack_speed"}],custom_data:{ts_cutting_tool:"cleaver",ts_name:"wooden_cleaver"},item_name:"Wooden Cleaver",max_damage:88,max_stack_size:1,rarity:"common",weapon:{}},count:1,id:"minecraft:wooden_sword"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:stick"},text:""},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:"  Farmer Hat
"},{text:"
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:wheat"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:wheat"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:wheat"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:wheat"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:108},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{custom_data:{ts_name:"farmer_hat"},equippable:{dispensable:true,slot:"head",swappable:true},item_name:"Farmer Hat",max_stack_size:1,rarity:"common"},count:1,id:"minecraft:leather_helmet"},text:""},{text:"

"},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:" Fisherman Hat
"},{text:"
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:leather"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:leather"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:cod"},text:""},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:leather"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:109},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{custom_data:{ts_name:"fisherman_hat"},equippable:{dispensable:true,slot:"head",swappable:true},item_name:"Fisherman Hat",max_stack_size:1,rarity:"common"},count:1,id:"minecraft:leather_helmet"},text:""},{text:"

"},{text:"

"}],text:""}},{raw:{extra:[{font:"minecraft:stwb",text:" Cutting Board
"},{text:"
"},{text:"
"},{color:"white",font:"tasty_supplies:recipe_book",text:""},{text:"


"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:stick"},text:""},{text:"

"},{font:"tasty_supplies:recipe_book",text:""},{color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",count:1,id:"minecraft:stick"},text:""},{font:"tasty_supplies:recipe_book",text:""},{click_event:{action:"change_page",page:110},color:"white",font:"tasty_supplies:recipe_book",hover_event:{action:"show_item",components:{custom_data:{ts_name:"cutting_board"},entity_data:{Invisible:true,Small:true,Tags:["cutting_board_placer"],id:"minecraft:armor_stand"},item_name:"Cutting Board",max_stack_size:64,rarity:"common"},count:1,id:"minecraft:armor_stand"},text:""},{text:"

"},{text:"

"}],text:""}}],resolved:false,title:"Tasty Supplies Cookbook"}] 1
