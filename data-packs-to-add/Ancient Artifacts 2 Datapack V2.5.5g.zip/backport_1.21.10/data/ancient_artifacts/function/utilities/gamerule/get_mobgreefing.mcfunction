return run gamerule mobGriefing
