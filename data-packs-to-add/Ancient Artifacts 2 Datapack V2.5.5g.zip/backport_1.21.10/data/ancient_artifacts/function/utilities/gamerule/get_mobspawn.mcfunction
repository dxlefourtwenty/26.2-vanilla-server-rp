return run gamerule spawnMonsters
