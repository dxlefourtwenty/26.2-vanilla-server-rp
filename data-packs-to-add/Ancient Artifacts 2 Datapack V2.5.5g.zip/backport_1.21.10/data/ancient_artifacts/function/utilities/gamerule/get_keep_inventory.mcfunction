return run gamerule keepInventory
