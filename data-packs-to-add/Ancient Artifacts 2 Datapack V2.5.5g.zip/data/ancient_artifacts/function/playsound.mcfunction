$playsound $(ID) $(source) $(target) $(pos) $(vol) $(pitch) $(minVol)
