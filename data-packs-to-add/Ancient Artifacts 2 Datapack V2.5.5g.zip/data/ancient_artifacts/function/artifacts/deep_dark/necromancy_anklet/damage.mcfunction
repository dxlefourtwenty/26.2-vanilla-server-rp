$damage @s $(damage) minecraft:generic_kill by @n[tag=damager]
