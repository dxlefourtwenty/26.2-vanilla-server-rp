kill @e[tag=pulse]
