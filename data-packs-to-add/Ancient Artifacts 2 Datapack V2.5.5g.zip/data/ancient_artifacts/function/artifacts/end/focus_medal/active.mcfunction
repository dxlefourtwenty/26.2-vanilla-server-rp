effect give @s hunger 1 2 true
