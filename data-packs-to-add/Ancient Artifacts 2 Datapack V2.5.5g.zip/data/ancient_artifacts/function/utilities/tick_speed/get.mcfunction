return run function ancient_artifacts:utilities/tick_speed/run {command: "return run tick query"}
