$particle minecraft:trail{color:$(color),duration:$(duration),target:$(pos)}
