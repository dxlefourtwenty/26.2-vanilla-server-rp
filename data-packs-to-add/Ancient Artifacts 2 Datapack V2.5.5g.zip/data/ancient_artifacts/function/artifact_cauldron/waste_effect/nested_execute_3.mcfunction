data merge storage theblackswitch:overlay {texture: "ancient_artifacts:item/overlay/artifact_waste/5", id: "ancient_artifacts:artifact_waste"}
function #theblackswitch:v2.0/overlay/modify
