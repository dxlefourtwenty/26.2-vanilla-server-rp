$data modify entity @s Motion[1] set value $(rand_motion)d
