return run gamerule doMobSpawning
